var s="/assets/static.10d84403.jpg";export{s as _};
